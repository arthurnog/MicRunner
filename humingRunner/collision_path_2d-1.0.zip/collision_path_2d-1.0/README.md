# Collision Path2D
## Instructions:

1. Install CollisionPath node under a CollisionPolygon2D
2. Add a Curve to the node
3. Options (node exports):
  * draw_points (bool): Whether points on polygon corners are drawn while editing the curve.
  * enabled (bool) Whether the curve is converted to polygon or not
  * max_stages (float) and tolerance_degrees (degrees): parameters of Curve.tesselate
